#!/bin/bash

qemu-system-x86_64  \
    -kernel ./bzImage \
    -nographic  \
    -no-reboot \
    -m 512M    \
    -append "root=/dev/ram console=ttyS0 oops=panic panic=1 nokaslr nosmep nosmap nopti quiet"   \
    -initrd rootfs.cpio.gz 
